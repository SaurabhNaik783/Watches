# Watches > 2024-10-16 5:02pm
https://universe.roboflow.com/watches-pwsrz/watches-8l3rs

Provided by a Roboflow user
License: CC BY 4.0

